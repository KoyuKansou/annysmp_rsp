#give magical to player
give @s minecraft:music_disc_13[minecraft:jukebox_playable="new_music:magical0",minecraft:custom_model_data={strings:["magical0"]}]